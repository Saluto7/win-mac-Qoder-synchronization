---
name: user-ai-health-career
description: JHU BME硕士在读，目标2027暑期AI模型、Agentic AI与可穿戴健康实习；Qwen经历重点是评测而非数据处理
metadata:
  type: user
---

截至2026-09-18，用户已入学Johns Hopkins University Biomedical Engineering M.S.E.，确认预计2028年6月毕业；SJTU BME本科与毕业设计已完成。

用户希望寻求2027年暑期AI Model、Wearable Data、Agentic AI方向实习。

用户在Alibaba/Qwen消费端医疗基模团队的经历重点为Agentic Eval：Grounded/Open Deep Search、工具调用与CoT评测。用户明确可穿戴相关经历主要是健康应用的Agentic评测，而不是原始传感器数据处理。未来求职叙述应强调评测设计、评分标准、人机评一致性和健康场景理解，不把经历改写为模型训练、评测自动化编码或数据工程；这些技能需另外确认。
