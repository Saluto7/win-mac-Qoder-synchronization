---
name: qoderwork-memory-b5ae50ed70d0
description: 长期记忆：[normal] EN.553.436/636 Intro to Data Science (Budavári, Fall2026, 4cr EQ)
metadata:
  type: feedback
---

[normal] EN.553.436/636 Intro to Data Science (Budavári, Fall2026, 4cr EQ)：HW30+Video20+Quiz50；Quiz纸质MCQ、每两周一次(9/9,9/23,...)、Strictly NAI；目录E:\EN.553.636.01(C0=syllabus,c1..cN=lecture)。
