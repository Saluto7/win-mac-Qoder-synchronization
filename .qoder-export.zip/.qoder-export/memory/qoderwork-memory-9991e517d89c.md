---
name: qoderwork-memory-9991e517d89c
description: 长期记忆：JHU SMILE需JHED+MFA，curl/WebFetch均403
metadata:
  type: feedback
---

JHU SMILE需JHED+MFA，curl/WebFetch均403；用builtin_browser登录，jobs.cfm?jlist点See All Listings按钮(勿form.submit)抓表；深链jobs.cfm?studentJob=on&jid=HASH。
