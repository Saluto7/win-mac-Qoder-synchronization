---
name: qoderwork-memory-111ddbfec8ee
description: 长期记忆：[normal] F-1关键陷阱
metadata:
  type: feedback
---

[normal] F-1关键陷阱：Full-time CPT累计≥12月=永久失去OPT；学期中只能part-time(≤20hr/w)不计入；Summer单次3个月full-time安全。
