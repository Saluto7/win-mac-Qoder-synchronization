---
name: user-computer-setup
description: 用户拥有联想 Y9000P RTX 3070 和美版基础配置 MacBook Air，关注双机学习分工与工作流迁移。
metadata:
  type: user
---
截至 2026-09-18，用户拥有一台联想 Y9000P（RTX 3070）和一台新换的美版基础配置 MacBook Air，Mac 用于平时学习。Mac 的具体年份、芯片、内存、存储容量尚未确认；不要把“最低配”直接等同于 8GB 内存。
用户正在考虑个人数据迁移、工作流保留和两台电脑的使用分工。给学习、编程和本地 AI 工具建议时，可考虑 Mac 的便携性与联想的 NVIDIA GPU，但未确认其已有远程连接或双机同步方案。
