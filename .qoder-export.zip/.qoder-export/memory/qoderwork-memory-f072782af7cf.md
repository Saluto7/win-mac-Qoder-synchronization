---
name: qoderwork-memory-f072782af7cf
description: 长期记忆：[normal] EN.580.680（=EN.580.480/680）是Precision Care Medicine I，项目制两学期设计课
metadata:
  type: feedback
---

[normal] EN.580.680（=EN.580.480/680）是Precision Care Medicine I，项目制两学期设计课；2026FA共7项目7队。课件与项目资料在E:\EN.580.680：slides/存放课件，PI/存放项目书（含8篇）。
