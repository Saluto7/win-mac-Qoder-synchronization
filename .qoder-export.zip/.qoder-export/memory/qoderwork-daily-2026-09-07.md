---
name: qoderwork-daily-2026-09-07
description: 2026-09-07 的近期活动与会话记忆
metadata:
  type: reference
---

## Session: 2027暑期实习准备清单
- 交付《Summer2027_实习准备时间线_JHU_BME.xlsx》：7 sheet（总览时间线/求职准备/公司清单39家/CPT身份/学术研究/Master Checklist 42任务/说明图例），存workspace outputs/
- 用户方向锁定：Medical AI Research + 工业ML双轨；目标大厂（Google/Meta/Apple/MSFT）+ 医疗AI独角兽（Tempus/Abridge/OpenEvidence/Ambience/Hippocratic）
- 三大分岔口置顶：①毕业时间线（1年MSE→OPT vs 1.5-2年→CPT）9月内与Bourne确认；②Full-time CPT累计12月+永久失OPT；③大厂Summer 2027窗口现在（9月）就开着
- 关键deadline时间轴：9/11加课→9/30 OIS check-in→10月大厂投递→11月独角兽投递→12月面试→2027/2接offer→2027/3启动CPT→2027/6实习开始
- 公司清单结构：Bay Area侧（Ambience/Hippocratic/Suki/Commure/Verily/Genentech）vs NYC侧（Tempus/Abridge/OpenEvidence/Cleerly/Ezra/Aidoc/Regeneron/MSKCC）
- 学术建议：Summer 2027前需1个可展示研究产出（ISBI/MICCAI abstract或arXiv）才能进Research Intern；候选JHU PI：Sulam/Thakar/Vogelstein/Sieweisen
- 验证踩坑：Windows Git Bash控制台GBK编码，python -c打印中文/emoji需-X utf8 + sys.stdout.reconfigure；否则UnicodeEncodeError
- 复用规格确认：微软雅黑+P0红F8CBAD/P1黄FFE699/P2绿C6E0B4+DV公式'☐ 未开始,◐ 进行中,☑ 已完成,⊘ 不适用'+冻结C3+隐网格线
