---
name: qoderwork-memory-fd237c84dcec
description: 长期记忆：[normal] JHU BME MSE 学位与课程政策
metadata:
  type: feedback
---

[normal] JHU BME MSE 学位与课程政策：全日制≥9cr、学期上限18cr；首学期SIS自动注册P/F在线必修课EN.500.603 Graduate Academic Ethics（约30min，Add期后出现在Canvas），未完成记F且需重修。30学分认定：任何JHU研究生600/700级math/science/engineering/medicine/public health课程经advisor批准均可计入；Seminar上限2门、Research上限6cr。8个focus areas为AIM/I&MD/Neuro/CompMed/BDS/G&SB/Immuno/TC&TE，课程不限BME系；EN.520.612在AIM+I&MD双方向推荐清单，EN.580.771是I&MD Core课。跨系/600+课程需Instructor signature，EN学生另加Professional Academic Advisor signature；跨division（SOM/Bloomberg/EP）走IDR表单+SEAM Case；500级课WSE每学年≤12cr、KSAS≤6cr。
