---
name: qoderwork-daily-2026-09-08
description: 2026-09-08 的近期活动与会话记忆
metadata:
  type: reference
---

## Session: 复习前两节课内容
- 担任EN.580.680(PCM I)助教，复习前两节课：9/1 Intro(Greenstein+Taylor)、9/3 Data Science&项目管理(Taylor)
- 关键急事：团队组建+项目排序(Project Ranking)截止9/8下午5pm(当天)；队名主题"水果"，交1、2志愿
- 评分：HW1 5%+期中计划30%+HW2 10%+期末40%+互评10%+出勤5%；HW1=DataCamp+合规培训(BHSR/COI/HPIR)+数据获取计划
- 数据平台：SAFER、PMAP、ARCH、Azure、All of Us；治理靠HIPAA/IRB/AI&Data Trust
- 9/3课要点：EHR数字化(2019医生89.9%用EMR)、Cures Act+HL7 FHIR、Vioxx案例、Epic Slicer Dicer、CRISP-DM六阶段、数据划分80/10/10、Tuckman团队模型
- 通读PI文件夹8篇项目论文；发现Uneri-Spinal Deformity是第8篇，未在9/1课件7项目列表中，需与队友/Canvas核对是否可选
- 与用户方向最契合：Selaru(Agentic AI药物发现,对上其千问Agentic Eval/Memory)、Chen/ReKinesis(可穿戴,Thakor为候选PI)
- 最稳易出成果：Pavlovich(前列腺AS,现成数据+AUC54-67%基线+专职统计师)、Gao(ARDS,合并数据集已备)

## Session: 复习数据科学前两课
- 担任EN.553.636助教复习Lec1(Intro+Descriptive)和Lec2(Distributions+Python)，用户明天(9/9)教室纸质MCQ quiz
- 材料源：E:\EN.553.636.01\{C0 syllabus, c1 01-Intro.pdf+01-Desc.ipynb, c2 02-Distributions.ipynb}；c3 Samples不在quiz范围
- 评分：HW30%+Video20%+Quiz50%；Quiz bi-weekly(下次9/23)、Strictly NAI；SDS可教室考或testing center延时
- Lec1要点：4象限(Sup/Unsup × Disc/Cont)、Y=f(X)+ε、Inference vs Prediction、Least Squares、Under/Overfit、PCA=旋转
- Lec1 Descriptive：mean/median/mode，方差分母N−1(unhomework)，MAD/median抗离群
- Lec2要点：PDF归一化=1，Uniform/Gaussian/Lognormal三分布support；CDF积分定义
- Lec2 Moments：skew=3阶归一化矩，kurt=4阶；Gaussian mvsk=(0,1,0,0)，U(−1,1)=(0,1/3,0,−1.2)，Lognormal(1)≈(1.65,4.67,6.18,110.9)
- Lec2 Python陷阱：a*a是elementwise、a@a是matmul；map()返回迭代器要list()；np.where返回索引；math.sin标量vs np.sin数组
