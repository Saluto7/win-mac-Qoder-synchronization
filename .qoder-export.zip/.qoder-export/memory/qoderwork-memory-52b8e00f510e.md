---
name: qoderwork-memory-52b8e00f510e
description: 长期记忆：浏览器连接器(key： qoderwork.settings.connector.builtin.browser)
metadata:
  type: feedback
---

浏览器连接器(key: qoderwork.settings.connector.builtin.browser)：即使显示disabled，extension可能已连接，enable后立即获得navigate/javascript_tool/read_page等17个MCP工具。Canvas(jhu.instructure.com)文件下载：用浏览器连接器navigate到/files/{id}/download?download_frd=1触发Chrome下载(存为UUID.tmp)；页内fetch()因重定向到CloudFront触发CORS失败。Canvas API: /api/v1/courses/{id}/modules?include[]=items 返回module items含content_id即file_id。
