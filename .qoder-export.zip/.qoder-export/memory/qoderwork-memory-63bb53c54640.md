---
name: qoderwork-memory-63bb53c54640
description: 长期记忆：[normal] 读.ipynb内容
metadata:
  type: feedback
---

[normal] 读.ipynb内容：json.load后遍历cells取source，outputs里stream取text、execute_result取data['text/plain']，跳过image/*即可拿全文。
