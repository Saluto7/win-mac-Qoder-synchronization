---
name: qoderwork-memory-d62a41f87d10
description: 长期记忆：留学生跨境资金
metadata:
  type: feedback
---

留学生跨境资金：学费走Flywire/Convera不占5万USD额度；房租优先RMB给中国室友(¥0成本)；小额USD用熊猫速汇0.4-0.7%；避免西联/信用卡取现。
