---
name: qoderwork-memory-02108e4a6a91
description: 长期记忆：[normal] openpyxl保存xlsx时若目标文件在Excel中打开会PermissionError
metadata:
  type: feedback
---

[normal] openpyxl保存xlsx时若目标文件在Excel中打开会PermissionError；改存_v2.xlsx新名而非删除锁文件。
