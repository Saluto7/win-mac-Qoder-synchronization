---
name: qoderwork-memory-9728005d5f43
description: 长期记忆：[normal] Bash heredoc传Python代码带单引号会EOF错
metadata:
  type: feedback
---

[normal] Bash heredoc传Python代码带单引号会EOF错；改写.py文件再`python script.py`执行更稳。
