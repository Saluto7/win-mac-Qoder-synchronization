---
name: 服务端配置层 persona/csp 与前端 persona hook 消费链路
description: 新增或修改服务端可配置环境变量;调整内容安全策略或排查前端资源被拦;替换电台人设昵称与主题色
metadata:
  type: project
  category: project_architecture
  source: auto
  keywords: config/persona.js, config/csp.js, publicPersona, usePersona, 狐琪 CHECK 约束
---

30天心情电台的配置与安全头收敛结构：
- 服务端可配置项统一收口到 server/src/config/ 目录：persona.js 从环境变量读取 DJ_NAME / PARTNER_A/B_NAME、PARTNER_A/B_COLOR、COUPLE_BACKSTORY（\\n 分隔多行）、COUPLE_ANNIVERSARIES，并提供 publicPersona() 只返回前端所需字段（不含 backstory/anniversaries，避免隐私泄漏）；csp.js 构建 helmet 的 ContentSecurityPolicy 指令集，由 CSP_ENABLED / CSP_REPORT_ONLY 两个开关控制启停与报告模式。
- llm.js 的系统提示词不再硬编码人名、城市、日期，全部由 PERSONA 解构拼接；mood.js 的错误响应复用 lib/errorHandler.js 的 debugDetail 只在非生产环境回传详情。
- 前端消费集中在 client/src/lib/persona.js（模块级缓存的 loadPersona + usePersona hook），RolePicker、MoodPage、DjChatBubble 均通过它获取昵称与主题色，不再手写狐/琪 映射（曾出现把 狐/kiki 写反的实现）。
- 角色键 `狐`/`琪` 与数据库 CHECK 约束绑定，刻意不做成可配置；网易云封面域名以 *.music.126.net 通配，client/index.html 无外部 CDN 与 Google Fonts，因此 script-src 'self' 不会误拦外域资源。
