---
name: Windows 上 os.open 未加 O_BINARY 导致 PNG 魔数识别失败
description: Windows 下上游脚本拒绝合法图片文件;排查图像格式预检失败的真实原因
metadata:
  type: feedback
  category: common_pitfalls_experience
  source: auto
  keywords: os.O_BINARY, Windows 文本模式, PNG 签名截断, prepare_source_image.py, Pillow 归一化兜底
---

Bug class: 上游 Python 脚本在 Windows 上把合法 PNG 判为"unsupported source image format"
Root cause: 上游 prepare_source_image.py 用 os.open(path, os.O_RDONLY) 打开文件（未加 os.O_BINARY），Windows 下文本模式会把字节 0x1A 当作 EOF 截断；其自检测函数只读前若干字节，PNG 签名 \x89PNG\r\n\x1a\n 中的 0x1A 被吃掉后签名校验失败，任何 PNG 都会被拒绝。该缺陷只在真正调用上游 preflight 时暴露，Pillow 的 Image.open 不受影响。
Fix pattern: 不修改上游仓库代码，在编排层自建 Pillow 归一化路径作为兜底——用 Pillow 打开源图、按 EXIF 方向转置、对 P/PA/LA/RGBA 先转 RGBA 再贴到白底上转为 RGB、输出单帧 PNG，并在 manifest 中记录 normalizer 来源以便区分走的是上游还是兜底。同时确认上游 compositor 是否另有依赖（compose_editorial.py 使用普通文件 API 不受此影响，但其字体接口要求 Pillow≥10，需另配隔离 venv）。
Reusable lesson: 不要相信上游脚本的格式预检在 Windows 上的结论，尤其是它用 os.open 做魔数识别时；应先独立用 Pillow 打开同一张图验证"图本身可读"，再定位是签名读取被截断还是真的格式不支持。适用于任何 Windows 下基于魔法字节判断文件类型的旧脚本；不适用于直接用标准库文件对象或 Pillow 打开文件的实现。
