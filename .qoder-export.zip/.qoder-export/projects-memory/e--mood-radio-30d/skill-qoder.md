---
name: 四张图片加工 Skill 聚合为 Qoder 插件与一图四图流水线脚本
description: 聚合多个上游 skill 打包为 Qoder 插件;编写跨 skill 的图片生成编排脚本;排查上游 skill 在 Windows 上的兼容问题
metadata:
  type: feedback
  category: task_summary_experience
  source: auto
  keywords: photo-quad-studio, skill 聚合插件, photo_quad.py, Qoder 插件打包, image generation pipeline, 上游 skill 导入
---

## 任务描述
- 核心需求：从 GitHub 导入 Photo-to-Editorial-Illustration、scene-distillation-zine-v1-3、photo-abstract-editorial、travel-memory-sticker-card 四个图片加工 skill，并合成一个脚本，使上传一张图片能得到四张生成结果图。
- 背景：目标仓库 e:\mood-radio-30d（30天心情电台）；Qoder 用户级 skill 发现目录为 C:\Users\<user>\.qoder\skills\<skill-name>/SKILL.md；插件打包遵循 .qoder-plugin/plugin.json 规范，可用 qoder-create-plugin 自带的 validate_qoder_plugin.py 离线校验。

## 执行过程
1. 通过 WebSearch/WebFetch 定位四个 skill 的真实仓库：Cynthia-cym/Photo-to-Editorial-Illustration、Zeejay0/gathered-scenes-zine-skill（内含 scene-distillation-zine-v1-3 等子 skill）、ZzzLc0405/photo-abstract-editorial、carolinaaafy/travel-memory-sticker-card。
2. git clone --depth 1 四个仓库到工作区临时目录 .skill-src，读取各 SKILL.md 及其 references/scripts 依赖，记录上游许可证差异（仅 job1 为 MIT，其余为个人非商业许可，禁止再分发）。
3. 用 PowerShell 脚本批量复制四个 skill 到 plugins/photo-quad-studio/skills/，并新建编排 skill skills/photo-quad/（SKILL.md + scripts/photo_quad.py + references/output-contract.md）。
4. photo_quad.py 实现 plan/compose/collect/runtime 四个子命令：plan 生成 manifest.json 与 RUN-SHEET.md；compose 调用上游 compose_editorial.py；collect 校验四张成品并生成 2x2 拼版图。
5. 发现上游 prepare_source_image.py 在 Windows 下失败：os.open 未加 os.O_BINARY，PNG 签名中的 0x1A 字节被文本模式截断，导致任何 PNG 都被判为"unsupported source image format"。不改动上游，改为在 photo_quad.py 内自建 Pillow 归一化兜底（EXIF 转置、RGBA→RGB 白底粘贴、输出单帧 PNG），manifest 记 normalizer=photo-quad-pillow。
6. 发现上游 compositor 需要 Pillow≥10（ImageFont.truetype 不支持 Path），本机 Pillow 9.4.0；接入上游 setup_image_runtime.py，新增 runtime 子命令 inspect/--approve-install，并在 manifest 中持久化 runtime_python，plan/compose 优先使用隔离 venv 的 python。
7. 新增 --python 全局参数与 runtime 子命令，注册到 plan/compose/runtime 三个子解析器；修复初版脚本中 01024 非法八进制字面量与缺失 import os。
8. 编写 plugin.json / README.md / assets/avatar.svg，运行 validate_qoder_plugin.py 报 OK；把 5 个 skill 复制到用户级 ~/.qoder/skills/。
9. 端到端验证：plan → ImageGen 四次并行生成 → compose（标题不得含标点，否则上游 _validate_copy 以 "title must contain 2–4 English words" 拒绝）→ collect --sheet，四张成品 + quad-contact-sheet.png 全部落地 final/。
10. 如实记录质量门缺陷：job3（photo-abstract-editorial）象牙面板上缺少 skill 要求的 2–5 词英文标题；job2 按 SKILL.md 要求交付中文创作想法、艺术指导七项与作者署名行。
11. .gitignore 补入 .skill-src 与 photo-quad-demo；删除自建临时脚本 debug_preflight.py、build-plugin.ps1。

## 相关文件
- /plugins/photo-quad-studio/.qoder-plugin/plugin.json
- /plugins/photo-quad-studio/README.md
- /plugins/photo-quad-studio/skills/photo-quad/SKILL.md
- /plugins/photo-quad-studio/skills/photo-quad/scripts/photo_quad.py
- /plugins/photo-quad-studio/skills/photo-quad/references/output-contract.md
- /.gitignore
- /skills/photo-abstract-editorial/（复制到用户级）
- /skills/scene-distillation-zine-v1-3/（复制到用户级）
- /skills/travel-memory-sticker-card/（复制到用户级）
- /skills/photo-to-editorial-illustration/（复制到用户级）

## 注意事项
- 走弯路：WebFetch 把 api.github.com 响应落盘为单行 UTF-16 文件，ripgrep(Grep) 显示 0 matches；改用 Read 或换一种检索方式才拿到结果。
- PowerShell 双引号字符串里的 $ 会被转义吃掉，变量赋值类脚本应写入文件再执行。
- 许可证风险：四个 skill 中仅 job1 为 MIT，其余明确禁止作为模板/插件/社区资源再分发，打包时必须显著声明并限定本地个人使用。
- 交付时不要因质量门未达标而悄悄重跑掩盖，应如实报告并由用户决定是否重算。

## 任务概览
成功交付：可分发插件包 plugins/photo-quad-studio（离线校验通过）、用户级安装的 5 个 skill、以及 plan/compose/collect/runtime 四子命令的 Python 编排脚本；以 client/src/assets/hero.png 完成一次真实的「一图四图」端到端验证，四张成品与 2x2 拼版图全部归档，并如实暴露 job3 缺英文标题的质量门缺陷。
