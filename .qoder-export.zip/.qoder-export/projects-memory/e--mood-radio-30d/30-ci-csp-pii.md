---
name: 30天心情电台工程治理四项落地（迁移框架/CI 门禁/CSP/PII 外置）
description: 维护心情电台数据库迁移框架与 schema 单一来源;排查 CI 门禁或冒烟测试失败;调整 CSP 策略或清理 llm prompt 中的 PII
metadata:
  type: feedback
  category: task_summary_experience
  source: auto
  keywords: 迁移框架, schema_migrations, CSP helmet, persona env, smoke 冒烟测试, CI 门禁
---

## 任务描述
- 核心需求：完成上一轮遗留的工程治理四项——7. 迁移链断裂（db/migrate.js、db/init.js、db/fix-roles.js 无调用方且 schema 多份副本）、8. CI 无门禁、9. CSP 关闭、10. server/src/llm.js 硬编码私人信息（人名/城市/日期）。
- 背景：仓库 e:\mood-radio-30d 为 Node ESM 前后端项目（server + client），数据库 better-sqlite3，部署 Fly.io。上一轮已删除部分遗留模块，但根 package.json 被删后留下空壳 package-lock.json 孤儿。

## 执行过程
1. 先核查文件系统实际状态（目录树快照滞后于上一轮删除）：确认 migrate-dj.js / migrations/ 已不存在，根无 package.json 但有空壳 package-lock.json（lockfileVersion 3、packages 为空对象），server/src/llm.js 存在而 services/llm.js 不存在。
2. 迁移链收敛：把 server/src/db/schema.sql 升级为唯一权威来源（补 reactions 表、sessions 索引，移除"仅供参考"注释）；新建 server/src/db/migrations/ 下 4 条有序迁移（001 补齐 users.ab_role 列、002 规范化 users 的 A/B→狐/琪、003 重建 recommendations 表补 CHECK '狐','琪' 并用 CASE 映射旧值、004 建部分唯一索引，重复数据走 deferred 语义不记账本）。
3. 改写 server/src/db/migrate.js 为纯同步 runner（显式注册表 MIGRATIONS、独立事务、ensureLedger）；CLI 拆到 server/scripts/db.mjs（migrate/status 两条命令），避免与 db.js 循环依赖；db.js 改为读 schema.sql + runMigrations。
4. 删除三个孤儿脚本 db/init.js、db/fix-roles.js、db/index.js（grep 确认零外部引用）；新增 server/test/migrations.test.js（23 用例，含旧库升级路径与幂等验证）。
5. PII 外置：新建 server/src/config/persona.js 从 env 读 DJ_NAME / PARTNER_A/B_NAME、COLOR、COUPLE_BACKSTORY、COUPLE_ANNIVERSARIES；llm.js 全部 prompt 改用 persona 拼接；新建 routes/persona.js 暴露公开字段（不含 backstory，隐私边界）；前端新增 client/src/lib/persona.js（带缓存 hook）消费 API，RolePicker / MoodPage / DjChatBubble 去硬编码，并顺手修掉 RolePicker 把 狐/kiki 写反的 bug。
6. CSP：新建 server/src/config/csp.js，构建策略（script-src 'self'、style-src 'self' + 'unsafe-inline'、img/media/connect *.music.126.net + blob/data:），通过 CSP_ENABLED / CSP_REPORT_ONLY 可关闭，首版默认 report-only 可零风险试运行；index.js 挂载 helmet + persona 路由。
7. CI 门禁：新建 .github/workflows/ci.yml（workflow_call 复用）+ 改造 deploy.yml 用 checks job 复用以保证两份配置不漂移；新建 server/scripts/smoke.mjs（临时 DB、直塞 session、零外网依赖、30 项断言）；根新建 package.json（纯编排、无 workspaces、--prefix 转发 lint/test/build/smoke，ci:check 串联四道门禁）。
8. 修复 7 处 react-hooks/set-state-in-effect error（派生 state、async IIFE、key 直接用 current?.id）并把 PlayerBar zustand 稳定动作补进依赖，使 lint 达到 0 error / 0 warning，门禁收紧 --max-warnings 0。
9. 验证：npm run ci:check exit 0（lint 0/0 → vitest 23/23 → build 359kB → smoke 30/30）；迁移在真实库连续两次「本次应用：（无），已应用过：4 条」；快照比对 7 表 0 行数差异、integrity_check ok；git grep PII 关键词 0 匹配。

## 相关文件
- /server/src/db/migrate.js
- /server/src/db/schema.sql
- /server/src/db/migrations/001_users_ab_role.js
- /server/src/db/migrations/002_normalize_ab_role.js
- /server/src/db/migrations/003_recommendations_role_check.js
- /server/src/db/migrations/004_unique_ab_role_index.js
- /server/src/config/persona.js
- /server/src/config/csp.js
- /server/src/routes/persona.js
- /.github/workflows/ci.yml

## 注意事项
- 迁移 002 最初把 recommendations 的值更新与 users 放在一起，测试立即暴露 CHECK constraint failed：旧表约束仍是 A/B，直接 UPDATE 会被旧约束拦住。值映射必须随重建表一步到位（CASE），单列 UPDATE 无法绕过旧 CHECK。
- 首次给根 package.json 加了 workspaces，因根 lockfile 是空壳且依赖 hoisting 会破坏 better-sqlite3 原生模块解析，最终撤掉，改用 --prefix 显式转发。
- PowerShell 里 $ 会被双引号字符串转义吃掉（Grep 扫描到 0 文件）、`*>` 重定向导致 UTF-16 编码让 node utf8 解析为空；复杂脚本写入文件执行更稳。
- PII 只清除了工作区，git 历史中仍有，需 git filter-repo 不可逆重写，已明确交由用户决策。

## 任务概览
四项工程治理全部完成并通过完整验证链路。遗留待用户决策：① git 历史中的 PII 需 filter-repo；② CSP 首次上线建议先在 Fly 设 CSP_REPORT_ONLY=true 观察误伤再 enforce；③ Dockerfile 设 NODE_ENV=production，COOKIE_SECRET 必须是 Fly secret 否则容器启动抛错；④ _backup-local-20260912 下两个 SQLite 快照文件因沙箱静默拦截未删（约 127KB，目录已被忽略）。
