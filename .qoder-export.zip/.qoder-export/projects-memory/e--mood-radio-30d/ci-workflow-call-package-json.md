---
name: CI 门禁 workflow_call 复用与根 package.json 七脚本编排
description: 修改或排查 CI 门禁流程与缓存配置;从仓库根执行测试构建或冒烟检查;PR 前置检查与部署前检查逻辑确认
metadata:
  type: project
  category: project_build_configuration
  source: auto
  keywords: ci.yml, workflow_call, smoke.mjs, npm --prefix, eslint max-warnings, CI 四道关卡
---

30天心情电台的 CI 门禁与根编排：
- 仓库根有 package.json（无依赖、无 workspaces，仅编排脚本）与对应的 package-lock.json，提供 lint / test / build / smoke / db:migrate / db:status / ci:check 七个脚本；ci:check 用 && 串联 lint → test → build → smoke，其中子目录脚本通过 npm --prefix server/client 转发。
- .github/workflows/ci.yml 声明 pull_request / workflow_dispatch / workflow_call，是门禁唯一权威定义（缓存路径为 client/node_modules 与 server/node_modules）；.github/workflows/deploy.yml 不重复写检查步骤，改用 checks job 复用 ci.yml 再由 deploy job needs checks，保证 PR 前置检查与部署前检查不会各自漂移。
- 门禁四道关卡：client 侧 eslint --max-warnings 0（已修复全部 react-hooks/set-state-in-effect error 与可修复 warning）、server 侧 vitest run、vite build、server/scripts/smoke.mjs。
- server/scripts/smoke.mjs 以 node child_process spawn 启动服务，使用临时 DB 文件与 LLM_PROVIDER=mock，会话由 better-sqlite3 直接往临时库插入 user+session（不走网易云登录），因此零外网依赖，适合 CI 运行。
- Dockerfile 三阶段构建仍独立于 CI，未纳入工作流。
