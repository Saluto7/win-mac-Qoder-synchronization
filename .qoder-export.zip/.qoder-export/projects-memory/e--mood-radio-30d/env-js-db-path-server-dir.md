---
name: 服务端 env.js 环境变量加载顺序与 DB_PATH 按 SERVER_DIR 解析规则
description: 新增或修改服务端环境变量时确认加载优先级;排查 .env 未生效或数据库路径指向错误;模块 import env.js 的位置排错
metadata:
  type: project
  category: project_environment_configuration
  source: auto
  keywords: env.js, dotenv 加载顺序, DB_PATH 相对路径, SERVER_DIR, cwd 无关
---

30天心情电台的服务端环境变量由 server/src/env.js 统一加载（非容器环境下必须在读 env 的模块中最早 import，db.js、middleware/crypto.js、lib/logger.js 均在文件顶部 import './env.js'）：
- 加载顺序：先加载 server/.env，再加载仓库根 .env 作为补位，dotenv 不会覆盖 process.env 中已存在的键。
- DB_PATH 解析：为绝对路径时原样使用；为相对路径时按 server/ 目录（SERVER_DIR）解析，缺省值为 server/data/app.db，从而消除 cwd 相关性——从仓库根启动与从 server/ 启动指向同一数据库。
- 因 index.js 中 `import 'dotenv/config'` 先于 `dotenv.config({path:'../.env'})` 执行，实际优先加载 cwd 下的 .env，故推荐把环境配置写在 server/.env 或仓库根 .env 中。
