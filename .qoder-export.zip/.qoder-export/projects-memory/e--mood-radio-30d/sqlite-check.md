---
name: SQLite 迁移写新枚举值会被旧表 CHECK 约束拦住的升级陷阱
description: 编写改造已有 CHECK 约束列的数据库迁移;排查迁移中途 CHECK constraint failed
metadata:
  type: feedback
  category: common_pitfalls_experience
  source: auto
  keywords: CHECK 约束, SQLite 迁移, 枚举值扩容, 建表重命名, CASE 映射
---

Bug class: SQLite 迁移中单列 UPDATE 被旧表 CHECK 约束拦住导致升级失败
Root cause: 给已有 CHECK 约束的列写入不在允许集合内的值时，SQLite 先校验旧约束再落盘。把「新增列」与「旧值规范化」放在同一条迁移、且对带约束的表（如 recommendations.ab_role，原约束为 A/B）直接 UPDATE 到新枚举值时，语句在旧约束层面即被拒绝，不会因为你随后要改约束而放行。
Fix pattern: 值规范化拆到只处理无约束列（users.ab_role 无旧约束，可安全 UPDATE），对带约束的表改为「建新表 → INSERT SELECT 时用 CASE 映射旧值 → DROP 旧表 → RENAME 新表 → 重建索引」，并在迁移开头检测现有 CHECK 是否已为目标值以支持幂等跳过；同时预检非法值并 deferred，避免模糊的 CHECK 报错。
Reusable lesson: 不要以为迁移会按你写的顺序依次生效——SQLite 会在每条语句经过当前表结构上的旧约束，写新值前必须先确认目标值是否已被旧约束允许；需要变更多枚举值的列时，用建表重命名一步完成结构变更与数据映射，而不是先 UPDATE 再改约束。适用于所有带 CHECK/外键的存量列枚举扩容；不适用于尚未加约束的空表或纯新增列。
