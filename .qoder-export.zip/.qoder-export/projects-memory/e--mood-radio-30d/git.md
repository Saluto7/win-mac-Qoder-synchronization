---
name: 破坏性 Git 操作在受限沙箱中被静默拦截需复核状态
description: 执行 git reset 或删除类危险操作前后;终端命令无输出但行为异常
metadata:
  type: feedback
  category: common_pitfalls_experience
  source: auto
  keywords: 沙箱静默拦截, reset hard 复核, 拒绝访问, 破坏性操作, 备份快照
---

Bug class: 破坏性 Git 操作在受限沙箱中被静默拦截而不报错
Root cause: 终端执行器以受限权限运行命令时，`git reset --hard` 这类会大量改写工作区的操作会被沙箱拒绝执行，返回的是空输出而非错误；随后的 `git log`、`git status` 同样无回显，只有再次独立核查 `HEAD` 与实际工作区状态时才暴露出操作根本没有生效。
Fix pattern: 对任何写操作，执行后必须用只读命令复核目标状态（`git rev-parse HEAD`、`git status --porcelain`），不能以"命令无输出"判定成功；若输出中出现 "程序无法运行: 拒绝访问"，说明是沙箱权限不足，应重新申请更高权限后重试，而不是猜测命令写错或工具缺失。
Reusable lesson: 不要依赖破坏性命令是否有输出来判断成败——空输出既可能是成功也可能是被拦截。必须在改写前建立快照（备份分支、补丁、文件副本），改写后用只读命令逐项比对快照与目标状态。适用于所有通过受限终端执行删除、重置、批量改动的场景；不适用于纯读取型命令（读取失败通常会直接抛错）。
