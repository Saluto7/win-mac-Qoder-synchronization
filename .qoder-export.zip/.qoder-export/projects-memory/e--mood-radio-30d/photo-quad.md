---
name: photo-quad 对单张真实照片执行一图四图生成与成品分装
description: 用 photo-quad 对照片执行四路风格生成;排查 compose 阶段 Pillow/venn 解释问题;图像生成提示词导致乱码文字渲染
metadata:
  type: feedback
  category: task_summary_experience
  source: auto
  keywords: photo-quad, plan compose collect, 隔离 venv 解释器, 质量门, 一图四图生成
---

## 任务描述
- 核心需求：用 photo-quad 对 E:\mood-radio-30d\Photos\Raw 下照片（先单张微信图片_20260914021222.jpg，后计划批量）跑四路风格生成，结果存入四个风格文件夹。
- 背景：项目 e:\mood-radio-30d（30天心情电台）；已存在用户级 skill photo-quad（scripts/photo_quad.py，含 plan/compose/collect/runtime 子命令）及四个上游加工 skill；源图 3456×4608 竖幅 3:4（ratio 0.75）。

## 执行过程
1. 确认源图存在与尺寸：Get-ChildItem 列 Raw 目录（约110张照片），Pillow 读图得 3456×4608、mode RGB、ratio 0.75 竖幅。
2. runtime 子命令取隔离 venv 解释器路径 C:\Users\<user>\AppData\Local\photo-to-editorial-illustration\runtime-v1\Scripts\python.exe（本机系统 Pillow 9.4，不满足上游 Pillow≥10）。
3. photo_quad.py plan --image <src> --work <workdir> --python <venv python>：生成 manifest.json + RUN-SHEET.md，orientation=portrait，job1 画布 768x1024（与源比完全吻合 deviation 0）、job2 1024x1792、job3 1024x1536、job4 1536x1024。
4. 分别读取各 job 参考文件装配提示词：job1 读 generation-prompt.md/quality-guardrails.md/style-media-grammar.md/face-policy.md；job3 读 photo-abstract-editorial-prompt.en.md；job4 读 style-guide.md。
5. 按 RUN-SHEET 画布尺寸并行发起 4 次 ImageGen（四 job 互无依赖，同批并行）。
6. job1 质量门评估（Read 插画板）：姿态/花束/沙发/暖墙光均正确、标准化编辑脸、brush-pen+marker 介质、暖白留白充足、无文字无照片嵌入 → PASS；compose --illustration ... --title "Arms Full of Spring" --subtitle "She keeps the whole soft season" --python <venv> 成功，产出 side-by-side 终图 4096×2731。
7. job2 首张未过质量门：模型把提示词里的段落文字当作画面内容渲染成底部一大块乱码文本，违反"仅原创插画/纸艺"与作者性文字规则；改为纯可见像素指令 + 限定唯一中文文字后重跑 1024x1792。
8. job3/job4 同时 Read 检查质量门（job3 需核对象牙面板上 2–5 词英文标题是否补齐）。

## 相关文件
- 无代码/配置改动（纯调用编排）；产出物在 photo-quad-runs/<name>/final/ 与四个风格结果目录

## 注意事项
- compose 必须显式传 --python <隔离 venv>，否则上游 compose_editorial.py 走 sys.executable（系统 Pillow 9.4）会因 ImageFont.truetype 不支持 Path 而失败。
- 给图像模型写提示词时，描述性段落会被模型当成画面内容渲染成乱码文字；需用"仅可见像素/唯一作者文字"类约束规避。
- 质量门不合格应如实重跑并报告，不可掩盖。

## 任务概览
部分完成：job1 已 compose 成功落地（4096×2731）；job2 首张因提示词导致乱码文字未过门并重跑；job3/job4 待质量检查；四个风格文件夹分装尚未收尾。
