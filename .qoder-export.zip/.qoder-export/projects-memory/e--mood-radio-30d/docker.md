---
name: Docker 多阶段构建配置
description: 修改或排查 Docker 镜像构建;部署到 Fly.io 前检查构建产物;容器内 ESM/原生模块启动失败排查
metadata:
  type: project
  category: project_build_configuration
  source: init
  keywords: Dockerfile三阶段, npm ci omit=dev, alpine, deploy.yml, flyctl
---

构建流程 (Dockerfile，远端 main @ e7cebf6 实测，三阶段，全部基于 node:22-alpine):
1. client-builder: 仅 COPY client/package.json + package-lock.json，`npm ci`，再 COPY client/ 全量，`npm run build` 产出 /client/dist
2. server-deps: COPY server/package.json + package-lock.json，`npm ci --omit=dev`（不再安装 python3/make/g++ 等原生编译依赖，better-sqlite3 依赖 musl 预编译产物）
3. 运行镜像: `COPY --from=server-deps /app/node_modules ./node_modules`、`COPY server/src ./src`、`COPY --from=client-builder /client/dist ./public`，`apk add su-exec`，EXPOSE 4000，ENV NODE_ENV=production / PORT=4000 / DB_PATH=/app/data/app.db / STATIC_DIR=/app/public，ENTRYPOINT /app/entrypoint.sh，CMD ["node","src/index.js"]

已知缺陷: 第 3 阶段没有 COPY server/package.json 到 /app，导致运行时缺失 `"type":"module"` 声明，ESM 源码会被当作 CommonJS 解析而启动失败。

CI: .github/workflows/deploy.yml 在 push main 时直接 `flyctl deploy --remote-only --yes`，无 lint/test/build 前置门禁。
