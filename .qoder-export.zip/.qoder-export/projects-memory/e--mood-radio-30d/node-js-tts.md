---
name: Node.js 前端与 TTS 技术栈
description: 了解项目使用的编程语言、框架和第三方库
metadata:
  type: project
  category: project_tech_stack
  source: init
  keywords: Node.js, msedge-tts, TTS
---

开发语言: Node.js (基于 Dockerfile 中的 node:20-bookworm-slim)

核心依赖:
- `msedge-tts`: 用于微软 Edge 的文本转语音服务
