---
name: 运行环境与启动配置
description: 启动或部署 Mood Radio 服务时确认端口与环境变量;排查容器启动失败或环境变量未生效;本地开发配置前后端代理
metadata:
  type: project
  category: project_environment_configuration
  source: init
  keywords: node22-alpine, PORT4000, DB_PATH, STATIC_DIR, NCM_API
---

运行环境（远端 main @ e7cebf6 实测）:
- 基础镜像: `node:22-alpine`（不再是 node:20-bookworm-slim）
- 环境变量: `NODE_ENV=production`, `PORT=4000`, `DB_PATH=/app/data/app.db`, `STATIC_DIR=/app/public`
- 容器启动: `CMD ["node","src/index.js"]`，ENTRYPOINT 为 /app/entrypoint.sh（chown /app/data 后 su-exec 切 node 用户）
- 监听端口: 4000（EXPOSE 4000，fly.toml internal_port=4000）
- 本地开发: 后端 `cd server; npm run dev`（nodemon，PORT 默认 4000）；前端 `cd client; npm run dev`（Vite 5173，proxy /api → http://localhost:4000）
- 环境变量文件: 仓库根有 `.env.example`；server 目录下另有 `.env`；因 index.js 中 `import 'dotenv/config'` 先于 `dotenv.config({path:'../.env'})` 执行，实际优先加载 cwd 下的 .env
- 外部依赖: 必须另行提供 NeteaseCloudMusicApi 服务（`NCM_API`，默认 http://localhost:3000），docker-compose.yml 中未包含该服务
