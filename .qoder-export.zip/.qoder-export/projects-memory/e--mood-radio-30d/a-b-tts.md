---
name: 心情电台 A/B 角色链路、每日电台写入出口与 TTS 音频流出口
description: 修改每日电台选歌或串词生成链路;排查角色占用或语音不更新问题;新增网易云代理相关接口
metadata:
  type: project
  category: project_architecture
  source: auto
  keywords: pick-role, ab_role, daily submit, TTS 落盘, 网易云代理, 音频流出口
---

30天心情电台前后端关键结构约束（e7cebf6 实测）：
- A/B 角色链路：服务端 `/api/auth/pick-role` 以 `users.ab_role` 为唯一归属，客户端入口为 client/src/components/RolePicker.jsx（接入 PickPage），提交后走 `/api/daily/submit` 作为唯一写入路径；`/api/recommend` 的 POST 已下线返回 410。
- 每日电台数据键以服务端返回的实际汉字 `'狐'`/`'琪'`（U+742A）为准，客户端必须使用同一字符索引，自行拼接或手写副本会永久静默失效。
- 音频流出口集中在 daily.js 与 mood.js 的 `/tts`，均挂 stream error 与 res close 保护，错误不再冒泡至 uncaughtException 导致进程退出。
- TTS 合成由 services/tts.js 的 synthesizeDjAudio 承担，按 day 做 inflight 并发去重并落盘 server/data/tts/dj-day{N}.mp3，缓存失效依赖 djScript.generatedAt 作为 URL 版本参数。
- 网易云交互统一在 ncm.js 发起，routes/netease.js、routes/song.js、services/netease.js 分别负责代理搜索/歌曲、播放地址与歌词，均需登录态。
- 前端 API 基址为相对 `/api`，后端静态目录由 STATIC_DIR 提供以实现同源部署。
