# Qoder 数据迁移指南（Windows → Mac）

## 本导出包内容

此文件夹包含从 Windows 机器导出的所有可迁移的 Qoder 数据。

## 在 Mac 上的恢复步骤

### 前提：Mac 上先安装好 Qoder，并确保 `~/.qoder/` 目录已生成

### 1. 恢复用户记忆（最重要）

```bash
cp -r ~/.qoder-export/memory/* ~/.qoder/memory/
```

### 2. 恢复设置

```bash
# 注意：合并而非覆盖，避免丢失 Mac 特有的配置
# settings.json 和 mcp.json 建议手动对比合并
cat ~/.qoder-export/settings/settings.json
cat ~/.qoder-export/settings/mcp.json
```

### 3. 重新安装 Skills

```bash
# 在 Qoder 中逐个重装，或手动复制
# 参考 skills-manifest/installed_skills.txt 列表
```

### 4. 恢复项目级记忆

```bash
# 项目记忆的路径与 Windows 不同，需要在 Mac 上打开对应项目后
# 手动将 projects-memory/ 下的内容合并到新项目的 memory 目录
```

### 5. 迁移对话历史（可选）

对话历史存储在 `~/.qoder/projects/*/*.jsonl` 中，但路径与项目目录绑定。
Windows 路径如 `C--Users-令狐枕岳-Documents-...` 在 Mac 上完全不同，因此：
- 不建议直接复制 .jsonl 文件
- 可以在 Qoder 中通过"历史会话"功能查找旧对话（如果 Qoder 支持账户级同步）

## 不可迁移的内容

- **Tasks（任务列表）**：绑定会话 UUID，跨机器无意义
- **对话历史的本地缓存**：路径与项目目录强绑定
- **浏览器连接器缓存**：与安装环境相关

## 建议的迁移顺序

1. Mac 上安装 Qoder + 登录账号
2. 复制 `memory/` 目录（恢复核心记忆）
3. 复制 `plans/` 目录
4. 重新安装 Skills
5. 手动合并 settings.json / mcp.json
6. 以后在新项目产生的记忆会自动积累

## 如何把导出包传到 Mac

任选一种：
- **AirDrop**（需要 Windows 端用第三方工具，不方便）
- **iCloud Drive**：把 `.qoder-export` 文件夹放到 iCloud Drive 同步目录
- **U盘**：最简单直接
- **GitHub 私有仓库**：`cd ~/.qoder-export && git init && git add . && git commit -m "export" && git push`
- **scp**：`scp -r ~/.qoder-export 用户名@Mac的IP:~/`
