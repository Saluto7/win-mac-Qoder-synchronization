# 百日纪念页重设计：礼物盒惊喜 / 地球双心 / 宝丽来照片墙主视觉 / 一句话便签

## Context

全站暖纸编辑风已上线（commits cc6a623 / 5d06742 / 08a11a3，Fly 已部署）。现在重设计 /anniversary 单页，四项需求：

1. 上海⇄巴尔的摩动画升级：地球插画上两颗心相连（更复杂精美）
2. 舍弃倒计时（惊喜是到点才让她打开）→ 换成**丝带礼物盒**：hover/点击轻晃打不开，解锁瞬间丝带散开盒盖掀起
3. 信 → 「想给对方的一句话」：单行输入；解锁后两句以**倾斜便签卡**并排贴在相册上方
4. 流动相册升为全页主视觉：**全幅宝丽来照片墙**（通栏三行反向流动 + 白边相框 + 胶带角 + 微旋转），UI 大胆

已确认决策（AskUserQuestion）：锁定态=丝带礼物盒；相册=全幅宝丽来照片墙；一句话=倾斜便签卡。

硬约束（沿用）：不新增 npm 依赖；**服务端零改动**（门控、/letters、/photos 契约全部不动，一句话长度仅前端约束）；根 `npm run ci:check` 全绿；frontend_style——组件内不写新硬编码色值，颜色走 Tailwind token / persona（例外：SVG 线稿墨色 #2b2620、照片遮罩白字）；解锁为服务端判定（北京 9/15 00:00 = 09-14T16:00Z，剩约 8 小时），部署必须赶在解锁前。

## A. 页面骨架重构（AnniversaryPage.jsx）

- `<main>` 去掉 `max-w-3xl`，改全宽；每个 section 自带内层 `mx-auto w-full max-w-3xl px-4`；相册 section 通栏、内层 `mx-auto w-full max-w-6xl px-4`（不用 100vw 技巧，避免横向滚动条与 sticky 导航冲突）
- 顺序（解锁态）：header → GiftBox → GlobeHearts → SentenceNotes（便签对句）→ SentenceBox → PolaroidWall（主视觉）→ MemoryTimeline
- 锁定态：header → GiftBox(locked) → GlobeHearts → SentenceBox（可写自己那句，对方封印）→ 一张合并的 LockedCard「一百天的照片与回忆，都封在这份礼物里」（替换原来两张占位卡）
- 保留：`showContent = unlocked || canManage`、`!abRole → RolePicker`、`onUnlock → load()` 的服务端为准刷新
- 删除 `CountdownCard.jsx`；`LetterBox.jsx` → `SentenceBox.jsx`；`PhotoFlow.jsx` → `PolaroidWall.jsx`；`TwinCityClock.jsx` → `GlobeHearts.jsx`（git 层面删+增，仅 AnniversaryPage 一处 import 需改）

## B. GiftBox.jsx（新，替代 CountdownCard）

- **锁定态**：内联 SVG 纸面礼物盒——墨线盒身（圆角矩形、不闭合轮廓、笔压粗细）、盒盖、十字丝带用 persona 双色（竖带 a 色、横带 b 色，opacity .5）、顶上蝴蝶结两笔弧；盒身一点 ink/.06 侧影
  - 文案：ed-label `100 DAYS` + 衬线 `这里有一份还没到时间的礼物` + `恋爱第 {togetherDays} 天`（静态数字，**无跳秒**）+ `北京时间 9 月 15 日 00:00 一起打开`
  - 交互：hover 与点击触发 `animate-wiggle`（一次性，靠 key 重挂载重播）；点击另弹 toast「嘘——第 100 天才能拆」
  - **保留归零自动解锁**：照搬 CountdownCard 的 interval + `now >= targetMs → onUnlock()`（不显示数字也要守住午夜自动翻态）
- **解锁态**：挂载即播一次性开盒动画（`lid-lift` 盒盖上掀 + `ribbon-fall` 丝带两段 scaleY 消失，fill both），随后定格为开盒插画 + 衬线 `第 {togetherDays} 天，礼物拆开了` + `往下翻，是我们的一百天`

## C. GlobeHearts.jsx（重写 TwinCityClock）

- SVG viewBox `0 0 400 240`，纸面墨线地球：
  - 球体：两段不闭合墨线弧（笔压 1.2–2）；经纬线 = 1 横椭圆 + 2 竖椭圆 hairline `rgba(43,38,32,.08)`
  - 大陆：3–4 块软笔刷 blob（墨 .07，故意不闭合）
  - 昼夜：半圆夜面 wash（墨 .05），按当前 UTC 时刻换算角度旋转（每分钟级更新即可，复用现有 1s tick 派生），让地球"真的在转"
- 双心：上海(琪色)与巴尔的摩(狐色)位置各一枚 heart path 实填 persona 色；每枚外圈 `pulse-ring`（scale .6→1.9 淡出，2.6s 循环）；心下 11px 城市名（persona 色）
- 连线：两心之间跨球面大圆弧——底层墨虚线 hairline + 上层 persona a 色细线 `draw-thread` 一次性描入（pathLength=100，dashoffset 100→0）+ 一枚小心沿弧飞行（SMIL `<animateMotion><mpath>`，6s 循环；`matchMedia('(prefers-reduced-motion: reduce)')` 为 true 时不渲染 SMIL 节点）
- SVG 下方保留现有双时钟卡（Sun/Moon + 衬线 tabular 数字 + 日期）与统计行（在一起天数 / 公里），样式不动

## D. SentenceBox.jsx + SentenceNotes（重写 LetterBox）

- `MAX = 60`；输入改单行 `<input>`（change 时去掉换行）；卡片内同步**衬线斜体 text-lg 实时预览**；计数 `n/60`；保存按钮文案「封存这一句」
- 旧长信兼容：加载到的 `mine.text` 原样显示、原样可存；仅当编辑后 >60 才拦保存并 toast「现在只写一句啦，≤60 字」——不截断、不丢旧数据
- 对方卡：锁定=火漆小封印（沿用现 seal 样式）+「这一句还封着」；解锁未拆=点击拆封按钮；拆后=衬线斜体大字展示；空=「（ta 没留下话）」
- **SentenceNotes**（同文件命名导出，解锁态渲染于相册上方）：两张便签卡并排（sm:grid-cols-2），`rotate-[-2deg]` / `rotate-[1.5deg]`，边框/底色用各自 persona 色（`${color}55` 边、`${color}14` 底），顶边一条胶带角（`bg-ink/10` 微旋），内为衬线斜体一句话 + 身份色圆点署名（狐/琪）；某侧为空则该便签显示「ta 把这句话留白了」
- 服务端契约不变：`GET/PUT /api/anniversary/letters`

## E. PolaroidWall.jsx（重写 PhotoFlow，主视觉）

- 通栏色带：`bg-ink/[0.03]` + 上下 `border-line` 发丝线；带内头部 = ed-label `100 DAYS · 流动相册` + 衬线 h2 `我们的一百天` + `{n} 张照片，一直在流动`；canManage 时右侧上传条（配文 input + 添加按钮，逻辑照搬：ACCEPT/6MB/串行上传/进度）
- 墙 = 三行 marquee（left / right / left），行速 46s / 58s / 70s（第三行内联 `animationDuration` 覆盖）；行内宝丽来尺寸递增 `h-40 w-36` / `h-32 w-28` / `h-48 w-40`
- 宝丽来 tile：`bg-panel p-2 pb-7 border border-line shadow-glass` 白边相框；内 img `ken-burns object-cover`；配文排在白边内（衬线斜体 text-[11px] ink2 truncate）；顶中一条胶带（`bg-ink/10`，微旋）；整张按 id hash 确定性微旋 ±2.5°（inline transform，非颜色）；hover 暂停沿用 `.marquee:hover .marquee-track`
- 保留：lazy 加载、灯箱（暗 scrim + 白字配文属媒体遮罩例外）、canManage 删除、空态虚线纸卡、shimmer 骨架
- 双份渲染做无缝循环的机制不动

## F. index.css 新增

- `@keyframes wiggle`（±2° 三摆）+ `.animate-wiggle`（once）
- `@keyframes pulse-ring` + `.pulse-ring`（`transform-box: fill-box; transform-origin: center`）
- `@keyframes draw-thread`（dashoffset 100→0，1.6s once both）
- `@keyframes lid-lift` / `ribbon-fall`（开盒一次性）
- reduced-motion 块追加：`.pulse-ring`、`.animate-wiggle`、`.fly-heart` 停；marquee/ken-burns 已在块内

## G. 提交与部署

单 commit：`feat(anniversary): 礼物盒惊喜替倒计时 + 地球双心连线 + 宝丽来照片墙主视觉 + 一句话便签`
→ 根 `npm run ci:check` → push → Actions 门禁 + Fly 部署（**必须赶在 09-14T16:00Z 解锁前**；若门禁慢，本页为纯前端改动，锁定态旧版仍安全）

## Verification

- ci:check 全绿（lint --max-warnings 0 / vitest 48 项 smoke / build）
- 本地 harness（visual.db 已有 3 张照片 + 双角色会话；会话过期就照 smoke 方式重插）：
  锁定（琪）/ 解锁（狐）× 移动 390×844 + 桌面 1280；断言：锁定态**无跳秒数字**、礼物盒与开盒态正确、地球双心+飞心+昼夜在、照片墙通栏三行宝丽来、便签卡倾斜成对、控制台无 error
- 部署后：生产 bundle 哈希变化 + `verify-prod.sh`（401 不变、SPA 回退、CORS）+ 生产 /login 截图回归
- 收尾 grep：`client/src/components/anniversary/` 无新硬编码 hex（persona 色与墨色例外）

## 风险

- **时间窗**：剩约 8 小时；单 commit 纯前端，最坏情况解锁时仍是上一版（功能不受影响）
- **旧长信**：不截断不丢数据，仅新编辑受 60 字约束（见 D）
- **SMIL 兼容/降级**：Chrome/Safari/FF 均支持 animateMotion；reduced-motion 下不挂载飞心节点
- **通栏重构**：main 去 max-w 后各 section 自管内宽，注意 NavBar sticky 不受影响（未改 nav、未给祖先加 overflow）
- **三行 marquee 性能**：img lazy + 现有 will-change 未用，照片量大时行数固定为 3，不随张数增加
- 遗留（与本页无关，仍需用户处理）：Fly 若有 PARTNER_*_COLOR secret 会覆盖 fly.toml；本地 .env 身份色仍是霓虹旧值
