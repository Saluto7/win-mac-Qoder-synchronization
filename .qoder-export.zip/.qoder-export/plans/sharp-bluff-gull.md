# 情侣纪念照 · 三文件夹批量加工方案

## Context（为什么这么做）

目标：把 `E:\mood-radio-30d\Photos` 下已按内容分好的三个子文件夹，用对应 skill 批量加工成情侣纪念风格成品图。核心诉求是**含人像的部分尽可能完整还原，其余部分可自由拼接**。

关键约束（已核实）：
- **ImageGen 是纯文本生成，无图像输入参数**。任何 skill 都无法让模型凭文字描述重画出"同一张脸"——只能重画一张相似但会走样的脸。因此"人像完整还原"**只能靠 Pillow 把真实照片像素合成进成品**，不能靠 prompt。
- 本机可用：`Pillow 9.4.0`、`numpy 2.4.3`。缺失：`rembg / onnxruntime / cv2 / pillow-heif`（人像抠图需联网装模型，本方案不采用）。
- 唯一能贴入真实照片像素的现成合成器是 `photo-to-editorial-illustration/scripts/compose_editorial.py`（392 行），逻辑可直接复用；其 `_load_font` 把 `Path` 传给 `ImageFont.truetype`，触发 Pillow≥10 报错。**不修改该上游文件**，改为新写一个 Pillow-9 安全的合成脚本复用其逻辑。
- 三个 skill 均为纯 prompt（scene-distillation-zine / photo-abstract-editorial / travel-memory-sticker-card 都无合成脚本）。scene-distillation-zine 从设计上排斥照片像素、刻意模糊人脸，**与人像还原目标冲突**，故人像文件夹改走合成路线，不再用它。

输入清单（含重叠，同一照片可归多个文件夹）：
| 输入文件夹 | 内容 | 数量 | 处理方式 |
|---|---|---|---|
| `photo-abstract-editorial` | 景色 | 23 | 原 skill 纯 ImageGen（无人脸，自由拼接） |
| `​​travel-memory-sticker-card`（名前带 U+200B） | 物件 | 11 | 原 skill 纯 ImageGen |
| `​​scene-distillation-zine-v1-3-Gathered Scenes`（名前带 U+200B） | 人像 | 46 | **新合成管线**：真照片 + 生成插画板 |

合计 80 张成品（先试产 3 张）。

## 输出结构（集中 Output 树）

```
E:/mood-radio-30d/Photos/Output/
  photo-abstract-editorial/     <源名>.png   (景色, 23)
  travel-memory-sticker-card/   <源名>.png   (物件, 11)
  couple-memorial-composite/    <源名>.png   (人像, 46)
```
文件名沿用源图 basename，统一输出 `.png`。

## 三条管线

### A · 景色 → photo-abstract-editorial（不改动 skill）
每张：Read 照片（多模态）→ 按 `photo-abstract-editorial/SKILL.md` + `references/photo-abstract-editorial-prompt.zh-CN.md` 组织 prompt → ImageGen 竖幅 `1024x1536` → 存 `Output/photo-abstract-editorial/<名>.png`。无人脸，"自由拼接"已满足，prompt 保持原样。

### B · 物件 → travel-memory-sticker-card（不改动 skill）
每张：Read 照片 → 按 `travel-memory-sticker-card/SKILL.md` + `references/style-guide.md`，选 6 个贴纸母题 + 3 个英文关键词 → ImageGen `1536x1024`(3:2) → 存 `Output/travel-memory-sticker-card/<名>.png`。prompt 保持原样。

### C · 人像 → 合成管线（新建脚本 + 新 prompt）
1. **新脚本** `E:/mood-radio-30d/scripts/compose_couple_memorial.py`：复用 `compose_editorial.py` 的合成逻辑（`_open_oriented` 做 EXIF 摆正、真实照片按板宽缩放并 `paste` 真实像素、生成插画板缩放拼接、Caveat 字体两行页脚），仅两处适配：
   - `_load_font` 用 `str(FONT_PATH)` 传参 → 兼容 Pillow 9.4；
   - `FONT_PATH` 只读引用上游 `photo-to-editorial-illustration/assets/fonts/Caveat-Regular.ttf`（不改上游）。
   - 接口：`--source-photo --illustration --title --subtitle --output`，与上游一致。
2. 每张：Read 情侣照 → 据画面定 `title`(2–4 英文词) + `subtitle`(4–8 英文词) → ImageGen **只生成装饰插画板/背景**（浪漫编辑风、从照片色调取色；人脸不进生成图，由真照片承载）→ 运行 `compose_couple_memorial.py` 把**真实照片像素**与生成板合成 → 存 `Output/couple-memorial-composite/<名>.png`。人脸 100% 保真。

## 待创建/修改文件
- 新建 `E:/mood-radio-30d/scripts/compose_couple_memorial.py`（复用上游合成逻辑，Pillow-9 安全）。
- 新建输出目录 `E:/mood-radio-30d/Photos/Output/{photo-abstract-editorial,travel-memory-sticker-card,couple-memorial-composite}/`。
- **不修改**任何已安装 skill 文件（三个 SKILL.md、compose_editorial.py 全部保持字节不变）。

## 执行节奏
1. **试产 3 张**：每个文件夹各取 1 张跑通（A/B 各 1 次 ImageGen；C 为 1 次 ImageGen 生成板 + 1 次合成）。用绝对路径展示 3 张成品给用户验收。
2. 用户满意后再批量跑剩余 77 张，按文件夹分批推进。
3. 路径含零宽字符 U+200B：用 Python `os.listdir`/glob 精确匹配输入文件夹，不手敲文件夹名。

## 验证
- 试产阶段：Read 回 3 张成品，确认 (A) 竖向照片+抽象面板；(B) 3:2 贴纸卡、6 贴纸 3 关键词；(C) **人脸与原照一致**（合成而非重画）、页脚标题正常、EXIF 方向正确。
- 批量阶段：每文件夹结束后核对 `Output/<风格>/` 文件数与输入数一致（景色 23 / 物件 11 / 人像 46），列出任何 ImageGen 失败或合成报错的条目，不静默跳过、不伪造。

## 取舍说明
- 景色/物件用纯 ImageGen：无真实像素保留，但无人脸、符合"其余自由拼接"。若后续想让景色也保留真实像素，可同样接合成脚本（本期不做）。
- 人像用"真照片 + 生成插画板"双联版式（非把情侣抠进生成场景）：离线、零安装、人脸精确。若想要"情侣嵌入生成浪漫场景"，需 Option B（装 rembg 抠图，联网+审批），本期不做。
